TienDaoRPG 0.2.0 - ma nguon beta

CHUA PHAI JAR CAI DAT. Chua duoc bien dich/kiem thu tren Paper 26.2.
Ban nay them:
- 5 dao, 25 ten ky nang
- double-sneak toggle skill mode
- 5 icon hotbar; chon slot 1-5 thi thi trien
- mana, cooldown co ban
- XP/cap tu luyen va luu du lieu YAML
- mob cap ngau nhien luc spawn va tang mau/sat thuong co ban

CAN KIEM THU/HOAN THIEN:
- Co the co khac biet API voi Paper 26.2; build.gradle dung paper-api 26.2.build.133-stable.
- Double Shift va hotbar tren Bedrock can kiem tra thuc te qua Geyser.
- He thong icon tam thay 5 item dau hotbar khi bat mode; plugin luu va khoi phuc khi tat/thoat/chet, nhung van nen thu tren server test va backup.
- Chi so mob va hieu ung ky nang la ban beta, chua can bang.
- Java toolchain 21; build bang Gradle voi ket noi repo Paper.

Build tren may tinh:
  gradle build
Jar neu build thanh cong: build/libs/TienDaoRPG-0.2.0.jar
