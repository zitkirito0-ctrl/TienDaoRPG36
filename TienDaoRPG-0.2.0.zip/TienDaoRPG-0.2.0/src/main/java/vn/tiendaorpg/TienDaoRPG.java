package vn.tiendaorpg;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.*;
import java.util.*;

public final class TienDaoRPG extends JavaPlugin implements Listener, CommandExecutor {
    private final Map<UUID, Profile> profiles = new HashMap<>();
    private final Map<UUID, Long[]> cooldowns = new HashMap<>();
    private final Map<UUID, ItemStack[]> savedHotbars = new HashMap<>();
    private final Random random = new Random();
    private NamespacedKey mobLevelKey;
    private File dataFile;

    private static final String[] DAO_KEYS = {"madao","chinhdao","tadao","thiendao","nhandao"};
    private static final String[] DAO_NAMES = {"Ma Đạo","Chính Đạo","Tà Đạo","Thiên Đạo","Nhân Đạo"};
    private static final String[][] SKILLS = {
        {"Ma Chưởng","Huyết Ảnh Bộ","Thôn Hồn","Ma Khí Bạo Phát","Vạn Ma Triều Tông"},
        {"Chính Khí Kiếm","Hộ Thể Chính Khí","Kiếm Ảnh Phân Quang","Kiếm Trận","Vạn Kiếm Quy Tông"},
        {"Độc Vụ","Tà Ấn","Phệ Linh Chú","Vạn Độc Thực Tâm","Tà Thần Giáng Thế"},
        {"Lôi Chưởng","Lôi Độn","Thiên Lôi Giáng","Lôi Vực","Thiên Phạt Cửu Tiêu"},
        {"Phá Sơn Quyền","Thiết Bố Sam","Khí Huyết Bùng Nổ","Nhân Vương Quyền","Bất Diệt Kim Thân"}
    };
    private static final Material[][] ICONS = {
        {Material.FIRE_CHARGE,Material.SUGAR,Material.ENDER_EYE,Material.BLAZE_POWDER,Material.WITHER_SKELETON_SKULL},
        {Material.IRON_SWORD,Material.SHIELD,Material.FEATHER,Material.IRON_BARS,Material.DIAMOND_SWORD},
        {Material.SPIDER_EYE,Material.PAPER,Material.POTION,Material.FERMENTED_SPIDER_EYE,Material.WITHER_ROSE},
        {Material.LIGHTNING_ROD,Material.RABBIT_FOOT,Material.TRIDENT,Material.COPPER_BLOCK,Material.NETHER_STAR},
        {Material.STONE,Material.IRON_CHESTPLATE,Material.GOLDEN_APPLE,Material.ANVIL,Material.NETHERITE_CHESTPLATE}
    };

    private static final class Profile {
        String dao = "";
        int level = 1, xp = 0, mana = 100;
    }

    @Override public void onEnable() {
        mobLevelKey = new NamespacedKey(this, "mob_level");
        dataFile = new File(getDataFolder(), "players.yml");
        getDataFolder().mkdirs();
        loadProfiles();
        Bukkit.getPluginManager().registerEvents(this, this);
        for (String c : List.of("tuvi","chonda","skill","tienadmin")) {
            PluginCommand pc = getCommand(c);
            if (pc != null) pc.setExecutor(this);
        }
        new BukkitRunnable() {
            @Override public void run() {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    Profile pr = profile(p);
                    pr.mana = Math.min(100, pr.mana + 5);
                    if (p.getInventory().getItem(0) != null && isSkillItem(p.getInventory().getItem(0))) {
                        // Mana display is refreshed on next skill-mode toggle; avoid changing selected slot.
                    }
                }
                saveProfiles();
            }
        }.runTaskTimer(this, 40L, 40L);
        getLogger().info("TienDaoRPG 0.2.0 enabled. This is a beta foundation; test on a backup server.");
    }

    @Override public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) restoreHotbar(p);
        saveProfiles();
    }

    private Profile profile(Player p) { return profiles.computeIfAbsent(p.getUniqueId(), id -> new Profile()); }

    @EventHandler public void onJoin(PlayerJoinEvent e) {
        Profile pr = profile(e.getPlayer());
        if (pr.mana < 0 || pr.mana > 100) pr.mana = 100;
        // Natural mobs get their level when first seen; see onSpawn.
    }

    @EventHandler public void onSpawn(org.bukkit.event.entity.CreatureSpawnEvent e) {
        if (e.getSpawnReason() == org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.CUSTOM) return;
        int level = 1 + random.nextInt(100);
        e.getEntity().getPersistentDataContainer().set(mobLevelKey, PersistentDataType.INTEGER, level);
        e.getEntity().setCustomName(ChatColor.GRAY + "[Lv." + level + "] " + prettyName(e.getEntity().getType().name()));
        e.getEntity().setCustomNameVisible(false);
        try {
            var attr = e.getEntity().getAttribute(Attribute.MAX_HEALTH);
            if (attr != null) {
                double base = Math.min(200.0, 20.0 + level * 1.5);
                attr.setBaseValue(base);
                e.getEntity().setHealth(Math.min(base, base));
            }
            var damage = e.getEntity().getAttribute(Attribute.ATTACK_DAMAGE);
            if (damage != null) damage.setBaseValue(Math.min(40.0, damage.getBaseValue() + level * 0.15));
        } catch (Exception ignored) {}
    }

    @EventHandler public void onDeath(EntityDeathEvent e) {
        LivingEntity mob = e.getEntity();
        Integer lvl = mob.getPersistentDataContainer().get(mobLevelKey, PersistentDataType.INTEGER);
        if (lvl == null) return;
        Player killer = mob.getKiller();
        if (killer == null) return;
        Profile pr = profile(killer);
        int reward = Math.max(1, lvl / 2);
        pr.xp += reward;
        while (pr.level < 100 && pr.xp >= xpRequired(pr.level)) {
            pr.xp -= xpRequired(pr.level);
            pr.level++;
            killer.sendMessage(ChatColor.GOLD + "Tu vi tang len cap " + pr.level + "!");
            killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
        }
        e.setDroppedExp(Math.min(100, lvl));
        killer.sendMessage(ChatColor.GREEN + "Đánh bại quái cấp " + lvl + ", nhận " + reward + " XP tu luyện.");
    }

    private int xpRequired(int level) { return 50 + level * 25; }
    private String prettyName(String s) { return s.toLowerCase(Locale.ROOT).replace('_',' '); }

    @EventHandler public void onSneak(PlayerToggleSneakEvent e) {
        if (!e.isSneaking()) return;
        Player p = e.getPlayer();
        // Sneak toggle can fire repeatedly; use a short debounce.
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        Long last = lastSneak.get(id);
        if (last != null && now - last < 450) {
            if (skillMode.contains(id)) restoreHotbar(p); else enterSkillMode(p);
            lastSneak.remove(id);
        } else lastSneak.put(id, now);
    }
    private final Map<UUID, Long> lastSneak = new HashMap<>();
    private final Set<UUID> skillMode = new HashSet<>();

    private void enterSkillMode(Player p) {
        Profile pr = profile(p);
        int d = daoIndex(pr.dao);
        if (d < 0) { p.sendMessage(ChatColor.RED + "Hãy chọn đạo trước: /chonda <madao|chinhdao|tadao|thiendao|nhandao>"); return; }
        if (savedHotbars.containsKey(p.getUniqueId())) return;
        ItemStack[] originals = new ItemStack[5];
        for (int i=0;i<5;i++) originals[i] = cloneOrNull(p.getInventory().getItem(i));
        savedHotbars.put(p.getUniqueId(), originals);
        for (int i=0;i<5;i++) p.getInventory().setItem(i, makeSkillItem(d, i, pr));
        skillMode.add(p.getUniqueId());
        p.sendMessage(ChatColor.LIGHT_PURPLE + "Đã bật chế độ kỹ năng. Chọn ô 1–5 để dùng chiêu; đúp Shift để tắt.");
    }

    private void restoreHotbar(Player p) {
        UUID id = p.getUniqueId();
        ItemStack[] old = savedHotbars.remove(id);
        if (old != null) for (int i=0;i<5;i++) p.getInventory().setItem(i, cloneOrNull(old[i]));
        skillMode.remove(id);
        if (p.isOnline()) p.sendMessage(ChatColor.GRAY + "Đã tắt chế độ kỹ năng.");
    }

    private ItemStack cloneOrNull(ItemStack i) { return i == null ? null : i.clone(); }
    private boolean isSkillItem(ItemStack i) {
        return i != null && i.hasItemMeta() && i.getItemMeta().getPersistentDataContainer().has(new NamespacedKey(this,"skill_slot"), PersistentDataType.INTEGER);
    }
    private ItemStack makeSkillItem(int d, int slot, Profile pr) {
        ItemStack item = new ItemStack(ICONS[d][slot]);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.LIGHT_PURPLE + "" + (slot+1) + ". " + SKILLS[d][slot]);
        meta.setLore(List.of(ChatColor.AQUA + "Mana: " + (15 + slot*5), ChatColor.GRAY + "Chọn ô này để thi triển"));
        meta.getPersistentDataContainer().set(new NamespacedKey(this,"skill_slot"), PersistentDataType.INTEGER, slot);
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler public void onHeld(PlayerItemHeldEvent e) {
        Player p = e.getPlayer();
        if (!skillMode.contains(p.getUniqueId())) return;
        int slot = e.getNewSlot();
        if (slot < 5) {
            Bukkit.getScheduler().runTask(this, () -> castSkill(p, slot));
        }
    }

    @EventHandler public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        restoreHotbarSilently(p);
        saveProfiles();
    }
    @EventHandler public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        // Ensure skill icons aren't dropped; restore originals after respawn.
        if (skillMode.contains(p.getUniqueId())) {
            e.getDrops().removeIf(this::isSkillItem);
            Bukkit.getScheduler().runTask(this, () -> restoreHotbar(p));
        }
    }
    private void restoreHotbarSilently(Player p) {
        ItemStack[] old = savedHotbars.remove(p.getUniqueId());
        if (old != null) for (int i=0;i<5;i++) p.getInventory().setItem(i, cloneOrNull(old[i]));
        skillMode.remove(p.getUniqueId());
    }

    private void castSkill(Player p, int slot) {
        Profile pr = profile(p);
        int d = daoIndex(pr.dao);
        if (d < 0 || slot < 0 || slot > 4) return;
        long now = System.currentTimeMillis();
        Long[] cd = cooldowns.computeIfAbsent(p.getUniqueId(), k -> new Long[]{0L,0L,0L,0L,0L});
        if (now < cd[slot]) { p.sendMessage(ChatColor.RED + "Chiêu đang hồi " + ((cd[slot]-now+999)/1000) + " giây."); return; }
        int cost = 15 + slot * 5;
        if (pr.mana < cost) { p.sendMessage(ChatColor.RED + "Không đủ mana. Cần " + cost + ", hiện có " + pr.mana + "."); return; }
        pr.mana -= cost;
        cd[slot] = now + (3000L + slot * 2000L);
        p.sendMessage(ChatColor.LIGHT_PURPLE + "Thi triển: " + SKILLS[d][slot] + " — mana " + pr.mana + "/100");
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ILLUSIONER_CAST_SPELL, 0.8f, 1.2f);
        double radius = slot == 4 ? 8 : slot == 3 ? 6 : 4;
        double damage = (4 + slot * 3) * (1 + pr.level * 0.03);
        int hits = 0;
        for (Entity ent : p.getNearbyEntities(radius, 3, radius)) {
            if (!(ent instanceof LivingEntity target) || target instanceof Player || target == p) continue;
            if (target.getLocation().distanceSquared(p.getLocation()) > radius*radius) continue;
            switch (d) {
                case 0 -> { target.damage(damage * (slot == 2 ? 1.4 : 1), p); if (slot == 2) p.setHealth(Math.min(p.getHealth()+2, Objects.requireNonNull(p.getAttribute(Attribute.MAX_HEALTH)).getValue())); }
                case 1 -> { target.damage(damage, p); if (slot == 1) p.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.RESISTANCE, 80, 1)); }
                case 2 -> { target.damage(damage, p); target.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.POISON, 100 + slot*20, 0)); }
                case 3 -> { target.getWorld().strikeLightningEffect(target.getLocation()); target.damage(damage * 1.2, p); }
                case 4 -> { target.damage(damage * 1.1, p); if (slot == 1 || slot == 4) p.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.RESISTANCE, 100, 1)); }
            }
            hits++;
        }
        if (hits == 0 && slot <= 1) p.sendMessage(ChatColor.GRAY + "Không có mục tiêu trong tầm chiêu.");
        for (int i=0;i<5;i++) p.getInventory().setItem(i, makeSkillItem(d,i,pr));
        saveProfiles();
    }

    private int daoIndex(String dao) { for (int i=0;i<DAO_KEYS.length;i++) if (DAO_KEYS[i].equals(dao)) return i; return -1; }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) { sender.sendMessage("Lenh nay chi dung trong game."); return true; }
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "tuvi" -> {
                Profile pr = profile(p);
                p.sendMessage(ChatColor.GOLD + "===== TIEN DAO RPG =====");
                p.sendMessage(ChatColor.YELLOW + "Đạo: " + (daoIndex(pr.dao)<0 ? "Chưa chọn" : DAO_NAMES[daoIndex(pr.dao)]));
                p.sendMessage(ChatColor.AQUA + "Mana: " + pr.mana + "/100");
                p.sendMessage(ChatColor.GREEN + "Cấp: " + pr.level + " | XP: " + pr.xp + "/" + xpRequired(pr.level));
                p.sendMessage(ChatColor.GRAY + "Đúp Shift để bật/tắt chế độ kỹ năng.");
            }
            case "chonda" -> {
                if (args.length != 1) { p.sendMessage(ChatColor.RED + "Dùng /chonda madao|chinhdao|tadao|thiendao|nhandao"); return true; }
                String key = args[0].toLowerCase(Locale.ROOT);
                int d = daoIndex(key);
                if (d < 0) { p.sendMessage(ChatColor.RED + "Đạo không hợp lệ."); return true; }
                Profile pr = profile(p); pr.dao = key; saveProfiles();
                p.sendMessage(ChatColor.GREEN + "Bạn đã chọn " + DAO_NAMES[d] + "!");
            }
            case "skill" -> {
                Profile pr = profile(p); int d = daoIndex(pr.dao);
                if (d < 0) { p.sendMessage(ChatColor.RED + "Chọn đạo trước bằng /chonda."); return true; }
                p.sendMessage(ChatColor.GOLD + "Kỹ năng " + DAO_NAMES[d] + ":");
                for (int i=0;i<5;i++) p.sendMessage(ChatColor.YELLOW + (i+1) + ". " + SKILLS[d][i] + " — mana " + (15+i*5) + ", hồi " + (3+i*2) + " giây");
            }
            case "tienadmin" -> {
                if (!p.hasPermission("tiendaorpg.admin")) { p.sendMessage(ChatColor.RED + "Bạn không có quyền."); return true; }
                if (args.length == 2 && args[0].equalsIgnoreCase("mana")) {
                    Player target = Bukkit.getPlayerExact(args[1]);
                    if (target != null) { profile(target).mana = 100; p.sendMessage("Đã hồi mana cho " + target.getName()); }
                    else p.sendMessage("Không tìm thấy người chơi online.");
                } else p.sendMessage("/tienadmin mana <player>");
            }
        }
        return true;
    }

    private void loadProfiles() {
        if (!dataFile.exists()) return;
        org.bukkit.configuration.file.YamlConfiguration y = org.bukkit.configuration.file.YamlConfiguration.loadConfiguration(dataFile);
        for (String id : y.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(id);
                Profile p = new Profile();
                p.dao = y.getString(id + ".dao", "");
                p.level = Math.max(1, Math.min(100, y.getInt(id + ".level", 1)));
                p.xp = Math.max(0, y.getInt(id + ".xp", 0));
                p.mana = Math.max(0, Math.min(100, y.getInt(id + ".mana", 100)));
                profiles.put(uuid, p);
            } catch (IllegalArgumentException ignored) {}
        }
    }
    private void saveProfiles() {
        if (dataFile == null) return;
        org.bukkit.configuration.file.YamlConfiguration y = new org.bukkit.configuration.file.YamlConfiguration();
        for (var entry : profiles.entrySet()) {
            String id = entry.getKey().toString(); Profile p = entry.getValue();
            y.set(id + ".dao", p.dao); y.set(id + ".level", p.level); y.set(id + ".xp", p.xp); y.set(id + ".mana", p.mana);
        }
        try { y.save(dataFile); } catch (IOException ex) { getLogger().severe("Cannot save player data: " + ex.getMessage()); }
    }
}
